module.exports = {
  Admin: 'admin',
  User: 'user',
};
